/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

import java.sql.*;
import java.util.*;

/**
 *
 * @author AFAN
 */
public abstract class EmployeeManagment implements AddProducts {

    // Private Attributes
    private String emp_code;
    private String emp_name;
    private double emp_salary;
    private String emp_address;
    private String status;

    // Constructor
    EmployeeManagment(String emp_code, String emp_name, double salary, String address, String status) {
        this.emp_code = emp_code;
        this.emp_name = emp_name;
        this.emp_address = address;
        this.status = status;
        if (salary > 0) {
            this.emp_salary = salary;
        } else {
            this.emp_salary = 0.0;
        }
    }

    // Setters
    public void setEmployeeCode(String emp_code) {
        this.emp_code = emp_code;
    }

    public void setEmployeeStatus(String status) {
        this.status = status;
    }

    public void setEmployeeName(String emp_name) {
        this.emp_name = emp_name;
    }

    public void setEmployeeSalary(double salary) {
        if (salary > 0) {
            this.emp_salary = salary;
        } else {
            this.emp_salary = 0.0;
        }
    }

    public void setEmployeeAddress(String address) {
        this.emp_address = address;
    }

    // Getters
    public String getEmployeeCode() {
        return emp_code;
    }

    public String getEmployeeStatus() {
        return status;
    }

    public String getEmployeeName() {
        return emp_name;
    }

    public double getEmployeeSalary() {
        return emp_salary;
    }

    public String getEmployeeAddress() {
        return emp_address;
    }

}
