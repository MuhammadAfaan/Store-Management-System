
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
public class StoreManagment {

    static String p_emp_code = null;
    static int transaction_id = 0;

    public static void main(String[] args) {
        Login login = new Login();
        login.show();
    }

}
