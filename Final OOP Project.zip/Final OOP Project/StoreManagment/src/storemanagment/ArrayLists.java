/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @AFAN
 */
public class ArrayLists {

    public static ArrayList<InventoryManagment> getProducts() {
        ArrayList<InventoryManagment> listproducts = new ArrayList<>();

        try {
            Connection con = DataBase.getConnection();
            String query = "Select * from product";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                String code = rs.getString("product_code");
                String name = rs.getString("product_name");
                int quantity = rs.getInt("product_quantity");
                float price = rs.getFloat("product_price");
                String s_code = rs.getString("s_code");
                String c_code = rs.getString("category_code");

                InventoryManagment im = new InventoryManagment(c_code, code, name, price, quantity, s_code);
                listproducts.add(im);
            }
            con.close();
            st.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listproducts;
    }

    public static ArrayList<EmployeeManagment> getEmployees() {

        ArrayList<EmployeeManagment> listemployees = new ArrayList<>();

        try {
            Connection conn = DataBase.getConnection();
            String query = "Select * from employee join login on employee.emp_code=login.emp_code";
            Statement statment = conn.createStatement();
            ResultSet resultSet = statment.executeQuery(query);
            while (resultSet.next()) {
                String code = resultSet.getString("emp_code");
                String name = resultSet.getString("emp_name");
                double salary = resultSet.getDouble("emp_salary");
                String status = resultSet.getString("emp_status");
                String address = resultSet.getString("emp_address");
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                if (status.equals("Manager")) {
                    Manager manager = new Manager(code, name, salary, address, username, password, status);
                    listemployees.add(manager);
                } else {
                    Cashier cashier = new Cashier(code, name, salary, address, username, password, status);
                    listemployees.add(cashier);

                }

            }
            conn.close();
            statment.close();
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listemployees;
    }

    public static ArrayList<SupplierManagment> getSuppliers() {

        ArrayList<SupplierManagment> listsuppliers = new ArrayList<>();

        try {
            Connection con = DataBase.getConnection();
            String query = "Select * from supplier";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                String code = rs.getString("s_code");
                String name = rs.getString("s_name");
                String address = rs.getString("s_address");
                Float sales = rs.getFloat("s_totalsales");
                SupplierManagment sm = new SupplierManagment(code, name, address, sales);
                listsuppliers.add(sm);
            }
            con.close();
            st.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listsuppliers;
    }

    public static ArrayList<CategoryManagement> getCategory() {

        ArrayList<CategoryManagement> listcategory = new ArrayList<>();

        try {
            Connection con = DataBase.getConnection();
            String query = "Select * from product_category";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                String code = rs.getString("category_code");
                String name = rs.getString("category_name");

                CategoryManagement sm = new CategoryManagement(code, name);
                listcategory.add(sm);
            }
            con.close();
            st.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listcategory;
    }

    public static ArrayList<CustomerManagment> getCustomer() {

        ArrayList<CustomerManagment> listcustomer = new ArrayList<>();

        try {
            Connection con = DataBase.getConnection();
            String query = "Select * from customer";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                String code = rs.getString("cus_code");
                String name = rs.getString("cus_name");
                String contact = rs.getString("cus_contact");
                String address = rs.getString("cus_address");

                CustomerManagment sm = new CustomerManagment(code, name, contact, address);
                listcustomer.add(sm);
            }
            con.close();
            st.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listcustomer;
    }

}
