/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
import java.sql.*;

import java.util.ArrayList;
import java.util.Random;
import storemanagment.DataBase;

public class Manager extends EmployeeManagment {

    // Attributes
    private String manager_username;
    private String manager_password;

    // Constructor
    public Manager(String emp_code, String emp_name, double salary, String emp_address, String manager_username,
            String manager_password, String status) {
        super(emp_code, emp_name, salary, emp_address, status);
        this.manager_username = manager_username;
        this.manager_password = manager_password;
    }
    public Manager() {
        super("", "", 0.0, "", "");
        this.manager_username = "";
        this.manager_password = "";
    }

    // Getters and Setters
    public String getManagerUsername() {
        return manager_username;
    }

    public void setManagerUsername(String manager_username) {
        this.manager_username = manager_username;
    }

    public String getManagerPassword() {
        return manager_password;
    }

    public void setManagerPassword(String manager_password) {
        this.manager_password = manager_password;
    }

    
    public static int addEmployee(String name, String address, float salary, String status, String username, String password) {
        try {
            Connection con = DataBase.getConnection();
            Random random = new Random();
            int empcod = random.nextInt(99000 - 10000 + 1) + 10000;
            String empcode = Integer.toString(empcod);
            while (Authentication.validateEmpCode(empcode)) {
                empcod = random.nextInt(99000 - 10000 + 1) + 10000;
                empcode = Integer.toString(empcod);
            }
            String query = "Insert into employee values (?,?,?,?,?)";
            String query2 = "Insert into login values (?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            PreparedStatement pst2 = con.prepareStatement(query2);

            pst.setString(1, empcode);
            pst.setString(2, name);
            pst.setFloat(3, salary);
            pst.setString(4, status);
            pst.setString(5, address);

            pst2.setString(1, username);
            pst2.setString(2, password);
            pst2.setString(3, empcode);
            pst.executeUpdate();
            pst2.executeUpdate();
            pst.close();
            pst2.close();
            con.close();

            return empcod;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static int addSupplier(String name, String address) {
        try {
            Connection con = DataBase.getConnection();
            Random random = new Random();
            float a = 0;
            int supcod = random.nextInt(99000 - 10000 + 1) + 10000;
            String supcode = Integer.toString(supcod);
            while (Authentication.validateSupCode(supcode)) {
                supcod = random.nextInt(99000 - 10000 + 1) + 10000;
                supcode = Integer.toString(supcod);
            }
            String query = "Insert into supplier values (?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, supcode);
            pst.setString(2, name);
            pst.setString(3, address);
            pst.setFloat(4, a);

            pst.executeUpdate();
            pst.close();
            con.close();
            return supcod;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static void updateEmployee(String emp_code, String name, String address, float salary, String username, String password) {
        try {
            Connection con = DataBase.getConnection();

            String query = "Update employee set emp_name=?,emp_salary=?,emp_address=? where emp_code=?";
            String query2 = "Update login set username=?,password=? where emp_code=?";

            PreparedStatement pst = con.prepareStatement(query);
            PreparedStatement pst2 = con.prepareStatement(query2);

            pst.setString(1, name);
            pst.setFloat(2, salary);
            pst.setString(3, address);
            pst.setString(4, emp_code);
            pst2.setString(1, username);
            pst2.setString(2, password);
            pst2.setString(3, emp_code);

            pst.executeUpdate();
            pst2.executeUpdate();
            pst.close();
            pst2.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

  @Override  
    public int addProduct(String name, float price, int quantity, String supplier, String category) {
        try {
            Connection con = DataBase.getConnection();
            Random random = new Random();
            int procod = random.nextInt(99000 - 10000 + 1) + 10000;
            String procode = Integer.toString(procod);
            while (Authentication.validateProCode(procode)) {
                procod = random.nextInt(99000 - 10000 + 1) + 10000;
                procode = Integer.toString(procod);
            }
            String query = "Insert into product values (?,?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, procode);
            pst.setString(2, name);
            pst.setInt(3, quantity);
            pst.setFloat(4, price);
            pst.setString(5, supplier);
            pst.setString(6, category);

            pst.executeUpdate();
            pst.close();
            con.close();
            return procod;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void updateStock(String code, String name, int quantity, float price) {
        try {
            Connection con = DataBase.getConnection();

            String query = "update product set product_name=?, product_quantity=?,product_price=? where product_code=?";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, name);
            pst.setInt(2, quantity);
            pst.setFloat(3, price);
            pst.setString(4, code);

            pst.executeUpdate();
            pst.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void requestStock(String sup_id, String pro_id, int quantity) {
        try {
            float sup_sale = 0;
            int pro_quant = 0;
            float pro_price = 0;
            Connection con = DataBase.getConnection();

            String query = "select s_totalsales from supplier where s_code = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, sup_id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                sup_sale = rs.getFloat("s_totalsales");
            }
            String query2 = "select product_quantity from product where product_code=?";
            PreparedStatement pst2 = con.prepareStatement(query2);
            pst2.setString(1, pro_id);
            ResultSet rs2 = pst2.executeQuery();
            while (rs2.next()) {
                pro_quant = rs2.getInt("product_quantity");
            }
            String query3 = "select product_price from product where product_code=?";
            PreparedStatement pst3 = con.prepareStatement(query3);
            pst3.setString(1, pro_id);
            ResultSet rs3 = pst3.executeQuery();
            while (rs3.next()) {
                pro_price = rs3.getFloat("product_price");
            }
            String query4 = "update supplier set s_totalsales=? where s_code=?";
            PreparedStatement pst4 = con.prepareStatement(query4);
            pst4.setFloat(1, sup_sale + (quantity * pro_price));
            pst4.setString(2, sup_id);

            pst4.executeUpdate();

            String query5 = "update product set product_quantity=? where product_code=?";
            PreparedStatement pst5 = con.prepareStatement(query5);
            pst5.setInt(1, quantity + pro_quant);
            pst5.setString(2, pro_id);

            pst5.executeUpdate();

            pst.close();
            pst2.close();
            pst3.close();
            pst4.close();
            pst5.close();

            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static int addCategory(String name) {
        try {
            Random random = new Random();
            int catcod = random.nextInt(99000 - 10000 + 1) + 10000;
            String catcode = Integer.toString(catcod);
            while (Authentication.validateCatCode(catcode)) {
                catcod = random.nextInt(99000 - 10000 + 1) + 10000;
                catcode = Integer.toString(catcod);
            }

            Connection con = DataBase.getConnection();

            String query = "insert into product_category values(?,?)";

            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, catcode);
            pst.setString(2, name);

            pst.executeUpdate();
            pst.close();
            con.close();
            return catcod;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

}
