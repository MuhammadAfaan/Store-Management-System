/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
public class CategoryManagement {
    private String cat_id;
    private String cat_name;
    
    public CategoryManagement(String cat_id,String cat_name){
    
    this.cat_id=cat_id;
    this.cat_name=cat_name;
    }
    public String getCategoryId() {
        return cat_id;
    }
       public String getCategoryName() {
        return cat_name;
    }
       
    public void setCategoryId(String cat_id) {
        this.cat_id=cat_id;
    }
    public void setCategoryName(String cat_name) {
        this.cat_name=cat_name;
    }
    
    
    
}