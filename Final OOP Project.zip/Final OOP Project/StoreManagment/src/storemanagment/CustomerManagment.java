/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

import java.sql.*;
import java.util.Random;

/**
 *
 * @author AFAN
 */
public class CustomerManagment {

    // Attributes
    private String customer_id;
    private String customer_name;
    private String customer_contact;
    private String customer_address;

    // Constructor
    public CustomerManagment(String customer_id, String customer_name, String customer_contact, String customer_address) {
        this.customer_id = customer_id;
        this.customer_name = customer_name;
        this.customer_contact = customer_contact;
        this.customer_address = customer_address;
    }

    // Getters
    public String getCustomerId() {
        return customer_id;
    }

    public String getCustomerName() {
        return customer_name;
    }

    public String getCustomerContact() {
        return customer_contact;
    }

    public String getCustomerAddress() {
        return customer_address;
    }

    // Setters
    public void setCustomerId(String customer_id) {
        this.customer_id = customer_id;
    }

    public void setCustomerName(String customer_name) {
        this.customer_name = customer_name;
    }

    public void setCustomerContact(String customer_contact) {
        this.customer_contact = customer_contact;
    }

    public void setCustomerAddress(String customer_address) {
        this.customer_address = customer_address;
    }

//    public static void addCustomer(String contact, String name, String address) {
//
//        try {
//            Random random = new Random();
//            int cuscod = random.nextInt(99000 - 10000 + 1) + 10000;
//            String cuscode = Integer.toString(cuscod);
//            Connection con = DataBase.getConnection();
//            String query = "Insert into customer values (?,?,?,?)";
//            PreparedStatement pst = con.prepareStatement(query);
//            pst.setString(1, cuscode);
//            pst.setString(2, name);
//            pst.setString(3, contact);
//            pst.setString(4, address);
//
//            pst.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//    }
}
