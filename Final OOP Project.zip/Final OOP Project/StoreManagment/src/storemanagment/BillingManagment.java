/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
import java.util.ArrayList;

public class BillingManagment {

    // Private Attributes
    private String transaction_id;
    private double transaction_amount;
    private int total_quantity;
    private double amount_paid;
    private double amount_returned;
    private ArrayList<InventoryManagment> products;

    // Constructor
    public BillingManagment(String transaction_id, double transaction_amount, int total_quantity, double amount_paid, double amount_returned, ArrayList<InventoryManagment> products) {
        this.transaction_id = transaction_id;
        this.transaction_amount = transaction_amount;
        this.total_quantity = total_quantity;
        this.amount_paid = amount_paid;
        this.amount_returned = amount_returned;
        this.products = products;
    }
    
    public BillingManagment(double transaction_amount, int total_quantity, double amount_paid, double amount_returned, ArrayList<InventoryManagment> products) {
        this.transaction_amount = transaction_amount;
        this.total_quantity = total_quantity;
        this.amount_paid = amount_paid;
        this.amount_returned = amount_returned;
        this.products = products;
    }

    // Getter and Setter for transaction_id
    public String getTransactionId() {
        return transaction_id;
    }

    public void setTransactionId(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    // Getter and Setter for transaction_amount
    public double getTransactionAmount() {
        return transaction_amount;
    }

    public void setTransactionAmount(double transaction_amount) {
        this.transaction_amount = transaction_amount;
    }

    // Getter and Setter for total_quantity
    public int getTotalQuantity() {
        return total_quantity;
    }

    public void setTotalQuantity(int total_quantity) {
        this.total_quantity = total_quantity;
    }

    // Getter and Setter for amount_paid
    public double getAmountPaid() {
        return amount_paid;
    }

    public void setAmountPaid(double amount_paid) {
        this.amount_paid = amount_paid;
    }

    // Getter and Setter for amount_returned
    public double getAmountReturned() {
        return amount_returned;
    }

    public void setAmountReturned(double amount_returned) {
        this.amount_returned = amount_returned;
    }

    // Getter and Setter for products
    public ArrayList<InventoryManagment> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<InventoryManagment> products) {
        this.products = products;
    }

}
