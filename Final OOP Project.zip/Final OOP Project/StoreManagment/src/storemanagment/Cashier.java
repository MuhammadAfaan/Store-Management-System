/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

import java.sql.*;
import java.util.*;

/**
 *
 * @author AFAN
 */
public class Cashier extends EmployeeManagment {

    // Attributes
    private String cashier_username;
    private String cashier_password;

    // Constructor
    public Cashier(String emp_code, String emp_name, double salary, String emp_address, String cashier_username, String cashier_password, String status) {
        super(emp_code, emp_name, salary, emp_address, status);
        this.cashier_username = cashier_username;
        this.cashier_password = cashier_password;

    }

    public Cashier() {
        super("", "", 0.0, "", "");
        this.cashier_password = "";
    }

    // Getters and Setters
    public String getCashierUsername() {
        return cashier_username;
    }

    public void setCashierUsername(String cashier_username) {
        this.cashier_username = cashier_username;
    }

    public String getCashierPassword() {
        return cashier_password;
    }

    public void setCashierPassword(String cashier_password) {
        this.cashier_password = cashier_password;
    }

    public static int addCustomer(String name, String contact, String address) {
        try {
            Connection con = DataBase.getConnection();
            Random random = new Random();
            int cuscod = random.nextInt(99000 - 10000 + 1) + 10000;
            String cuscode = Integer.toString(cuscod);
            while (Authentication.validateCusCode(cuscode)) {
                cuscod = random.nextInt(99000 - 10000 + 1) + 10000;
                cuscode = Integer.toString(cuscod);
            }

            String query = "Insert into customer values (?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, cuscode);
            pst.setString(2, name);
            pst.setString(3, contact);
            pst.setString(4, address);

            pst.executeUpdate();
            pst.close();
            con.close();
            return cuscod;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    
    public static void updateCustomer(String cus_code, String name, String contact, String address) {
        try {
            Connection con = DataBase.getConnection();

            String query = "update customer set cus_name=?,cus_contact=?,cus_address=? where cus_code=?";
            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, name);
            pst.setString(2, contact);
            pst.setString(3, address);
            pst.setString(4, cus_code);

            pst.executeUpdate();
            pst.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int addProduct(String name, float price, int quantity, String supplier, String category) {
        try {
            Connection con = DataBase.getConnection();
            Random random = new Random();
            int procod = random.nextInt(99000 - 10000 + 1) + 10000;
            String procode = Integer.toString(procod);
            while (Authentication.validateProCode(procode)) {
                procod = random.nextInt(99000 - 10000 + 1) + 10000;
                procode = Integer.toString(procod);
            }
            String query = "Insert into product values (?,?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, procode);
            pst.setString(2, name);
            pst.setInt(3, quantity);
            pst.setFloat(4, price);
            pst.setString(5, supplier);
            pst.setString(6, category);

            pst.executeUpdate();
            pst.close();
            con.close();
            return procod;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void updateStock(String code, String name, int quantity, float price) {
        try {
            Connection con = DataBase.getConnection();

            String query = "update product set product_name=?, product_quantity=?,product_price=? where product_code=?";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, name);
            pst.setInt(2, quantity);
            pst.setFloat(3, price);
            pst.setString(4, code);

            pst.executeUpdate();
            pst.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static int insertBill(BillingManagment bill) throws SQLException {
        Connection conn = null;
        PreparedStatement transactionStatement = null;
        ResultSet generatedKeys = null;

        try {
            conn = DataBase.getConnection();
            conn.setAutoCommit(false);
            Random random = new Random();
            int t_id = random.nextInt(99000 - 10000 + 1) + 10000;
            while (Authentication.validateTransaction(t_id)) {
                t_id = random.nextInt(99000 - 10000 + 1) + 10000;
            }
            String insertTransactionQuery = "INSERT INTO \"transaction\" (transaction_id, emp_code, t_amount, amount_paid, amount_returned, total_quantity) VALUES (?, ?, ?, ?, ?, ?)";
            transactionStatement = conn.prepareStatement(insertTransactionQuery);
            transactionStatement.setInt(1, t_id);
            transactionStatement.setString(2, StoreManagment.p_emp_code);
            transactionStatement.setDouble(3, bill.getTransactionAmount());
            transactionStatement.setDouble(4, bill.getAmountPaid());
            transactionStatement.setDouble(5, bill.getAmountReturned());
            transactionStatement.setInt(6, bill.getTotalQuantity());
            transactionStatement.executeUpdate();

            // Insert into transaction_products_relation table
            String insertTransactionProductsRelationQuery = "INSERT INTO transaction_products_relation (transaction_id, product_code, product_quantity) VALUES (?, ?, ?)";
            PreparedStatement transactionProductsRelationStatement = conn.prepareStatement(insertTransactionProductsRelationQuery);

            for (InventoryManagment product : bill.getProducts()) {
                transactionProductsRelationStatement.setInt(1, t_id);
                transactionProductsRelationStatement.setString(2, product.getProductCode());
                transactionProductsRelationStatement.setInt(3, product.getQuantity());
                transactionProductsRelationStatement.executeUpdate();
            }

            ArrayList<InventoryManagment> billProducts = bill.getProducts();
            ArrayList<InventoryManagment> totalProducts = ArrayLists.getProducts();
            int quantity;
            String updateQuantityQuery = "UPDATE product SET product_quantity = ? WHERE product_code = ?;";
            PreparedStatement pstm = conn.prepareStatement(updateQuantityQuery);

            for (InventoryManagment billProduct : billProducts) {
                for (InventoryManagment totalProduct : totalProducts) {
                    if (billProduct.getProductCode().equals(totalProduct.getProductCode())) {
                        int newQuantity = totalProduct.getQuantity() - billProduct.getQuantity();
                        pstm.setInt(1, newQuantity);
                        pstm.setString(2, billProduct.getProductCode());
                        pstm.executeUpdate();

                    }
                }
            }

            conn.commit();
            conn.close();
            StoreManagment.transaction_id = t_id;
            return t_id;
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback(); // Rollback transaction if an exception occurs
            }
            e.printStackTrace();
        } finally {
            // Close resources in finally block to ensure they are always closed
            if (generatedKeys != null) {
                generatedKeys.close();
            }
            if (transactionStatement != null) {
                transactionStatement.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return 0;
    }

    public static void returnBill(int t_id, String p_id, int quantity) {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rset = null;
        PreparedStatement pst2 = null;

        try {
            con = DataBase.getConnection();
            //Getting product quantity
            String query = "SELECT product_quantity FROM transaction_products_relation WHERE transaction_id = ? AND product_code = ?;";
            pst = con.prepareStatement(query);
            pst.setInt(1, t_id);
            pst.setString(2, p_id);
            rset = pst.executeQuery();

            int quan = 0;
            if (rset.next()) {
                quan = rset.getInt("product_quantity");
            }

            //Updating in Transaction
            int newQuantity = quan - quantity;
            String query2 = "UPDATE transaction_products_relation SET product_quantity = ? WHERE transaction_id = ? AND product_code = ?;";
            pst2 = con.prepareStatement(query2);
            pst2.setInt(1, newQuantity);
            pst2.setInt(2, t_id);
            pst2.setString(3, p_id);
            pst2.executeUpdate();

            //Getting total product Quantity
            String query4 = "SELECT product_quantity FROM product WHERE product_code = ?;";
            PreparedStatement pst4 = con.prepareStatement(query4);
            pst4.setString(1, p_id);
            ResultSet rset1 = pst4.executeQuery();

            int quan1 = 0;
            if (rset1.next()) {
                quan1 = rset1.getInt("product_quantity");
            }

            //Updating in Product
            int newPQuantity = quan1 + quantity;
            String query3 = "Update product SET product_quantity= ? where (product_code = ?);";
            PreparedStatement pst3 = con.prepareStatement(query3);
            pst3.setInt(1, newPQuantity);
            pst3.setString(2, p_id);
            pst3.executeUpdate();

            //Updating further transaction
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rset != null) {
                    rset.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (pst2 != null) {
                    pst2.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
