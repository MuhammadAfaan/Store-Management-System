/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBase {

    public static Connection getConnection() {

        String Url = "jdbc:sqlite:store.db";
        Connection connection = null;
        Statement statement = null;
        try {
            // Establishing Connection
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(Url);

            // Creating a statement
            statement = connection.createStatement();

            // Create customer table
            String createCustomerTableQuery = "CREATE TABLE IF NOT EXISTS customer ("
                    + "  cus_code CHAR(5) NOT NULL,"
                    + "  cus_name VARCHAR(30) NOT NULL,"
                    + "  cus_contact VARCHAR(13) NOT NULL,"
                    + "  cus_address VARCHAR(50) NULL DEFAULT NULL,"
                    + "  PRIMARY KEY (cus_code));";

            // Create employee table
            String createEmployeeTableQuery = "CREATE TABLE IF NOT EXISTS employee ("
                    + "  emp_code CHAR(5) NOT NULL,"
                    + "  emp_name VARCHAR(30) NOT NULL,"
                    + "  emp_salary FLOAT NOT NULL,"
                    + "  emp_status TEXT CHECK (emp_status IN ('Cashier', 'Manager')) NOT NULL,"
                    + "  emp_address VARCHAR(45) NULL DEFAULT NULL,"
                    + "  PRIMARY KEY (emp_code));";

            // Create login table
            String createLoginTableQuery = "CREATE TABLE IF NOT EXISTS `login` (\n"
                    + "  `username` VARCHAR(20) NOT NULL,\n"
                    + "  `password` VARCHAR(20) NOT NULL,\n"
                    + "  `emp_code` VARCHAR(5) NOT NULL,\n"
                    + "  PRIMARY KEY (`username`),\n"
                    + "  CONSTRAINT `login_employee`\n"
                    + "    FOREIGN KEY (`emp_code`)\n"
                    + "    REFERENCES `employee` (`emp_code`));";

            // Create product_category table
            String createProductCategoryTableQuery = "CREATE TABLE IF NOT EXISTS `product_category` (\n"
                    + "  `category_code` CHAR(5) NOT NULL,\n"
                    + "  `category_name` VARCHAR(50) NOT NULL,\n"
                    + "  PRIMARY KEY (`category_code`));";

            // Create supplier table
            String createSupplierTableQuery = "CREATE TABLE IF NOT EXISTS `supplier` (\n"
                    + "  `s_code` CHAR(5) NOT NULL,\n"
                    + "  `s_name` VARCHAR(30) NOT NULL,\n"
                    + "  `s_address` VARCHAR(50) NULL DEFAULT NULL,\n"
                    + "  `s_totalsales` FLOAT NULL DEFAULT NULL,\n"
                    + "  PRIMARY KEY (`s_code`));";

            // Create product table
            String createProductTableQuery = "CREATE TABLE IF NOT EXISTS `product` (\n"
                    + "  `product_code` CHAR(5) NOT NULL,\n"
                    + "  `product_name` VARCHAR(45) NOT NULL,\n"
                    + "  `product_quantity` INT NOT NULL,\n"
                    + "  `product_price` FLOAT NOT NULL,\n"
                    + "  `s_code` CHAR(5) NOT NULL,\n"
                    + "  `category_code` CHAR(5) NOT NULL,\n"
                    + "  PRIMARY KEY (`product_code`),\n"
                    + "  CONSTRAINT `product_category`\n"
                    + "    FOREIGN KEY (`category_code`)\n"
                    + "    REFERENCES `product_category` (`category_code`),\n"
                    + "  CONSTRAINT `product_supplier`\n"
                    + "    FOREIGN KEY (`s_code`)\n"
                    + "    REFERENCES `supplier` (`s_code`));";

            // Create transaction table
            String createTransactionTableQuery = "CREATE TABLE IF NOT EXISTS 'transaction' (\n"
                + "  transaction_id INTEGER NOT NULL,\n"
                + "  emp_code CHAR(5) NOT NULL,\n"
                + "  t_datetime DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n"
                + "  t_amount FLOAT NOT NULL,\n"
                + "  amount_paid FLOAT NOT NULL,\n"
                + "  amount_returned FLOAT NOT NULL,\n"
                + "  total_quantity INT NOT NULL,\n"
                + "  PRIMARY KEY (transaction_id),\n"
                + "  CONSTRAINT transction_employee\n"
                + "    FOREIGN KEY (emp_code)\n"
                + "    REFERENCES employee (emp_code)\n"
                + "    ON DELETE NO ACTION\n"
                + "    ON UPDATE NO ACTION\n"
                + ");";


            // Create transaction_products_relation table
            String createTransactionProductsRelationTableQuery = "CREATE TABLE IF NOT EXISTS `transaction_products_relation` (\n"
                    + "  `transaction_id` INT NOT NULL,\n"
                    + "  `product_code` CHAR(5) NOT NULL,\n"
                    + "  `product_quantity` INT NOT NULL,\n"
                    + "  CONSTRAINT `transaction_product`\n"
                    + "    FOREIGN KEY (`product_code`)\n"
                    + "    REFERENCES `product` (`product_code`),\n"
                    + "  CONSTRAINT `transaction_relation`\n"
                    + "    FOREIGN KEY (`transaction_id`)\n"
                    + "    REFERENCES `transaction` (`transaction_id`));";

            // Executing the create table statments
            statement.executeUpdate(createCustomerTableQuery);
            statement.executeUpdate(createEmployeeTableQuery);
            statement.executeUpdate(createLoginTableQuery);
            statement.executeUpdate(createProductCategoryTableQuery);
            statement.executeUpdate(createSupplierTableQuery);
            statement.executeUpdate(createProductTableQuery);
            statement.executeUpdate(createTransactionTableQuery);
            statement.executeUpdate(createTransactionProductsRelationTableQuery);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
