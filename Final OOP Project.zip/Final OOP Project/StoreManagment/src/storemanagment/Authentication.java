/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author AFAN
 */
public class Authentication {

    public static boolean checkProductId(String pro_id) {
        try {

            Connection con = DataBase.getConnection();
            ResultSet rs = null;
            String query = "Select product_code from product WHERE product_code = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, pro_id);
            rs = pst.executeQuery();
            if (rs.next()) {
                con.close();
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static boolean getLoginAuthentication(String username, String password, String emp_status) {

        try {
            Connection conn = DataBase.getConnection();
//            ResultSet resultSet = null;

            String sqlQuery = "SELECT e.emp_code FROM employee e JOIN login l ON e.emp_code = l.emp_code WHERE (username = ?) AND (password = ?) AND (emp_status = ?);";
            PreparedStatement preparedStatement = conn.prepareStatement(sqlQuery);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, emp_status);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                preparedStatement.close();
                conn.close();
                resultSet.close();
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    
    //Validations
    public static boolean validateEmpCode(String empCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DataBase.getConnection();

            String query = "SELECT emp_code FROM employee WHERE emp_code = ?;";
            pst = conn.prepareStatement(query);
            pst.setString(1, empCode);
            rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
    
    public static boolean validateProCode(String proCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DataBase.getConnection();

            String query = "SELECT product_code FROM product WHERE product_code = ?;";
            pst = conn.prepareStatement(query);
            pst.setString(1, proCode);
            rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
    
    public static boolean validateCatCode(String catCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DataBase.getConnection();

            String query = "SELECT category_code FROM product_category WHERE category_code = ?;";
            pst = conn.prepareStatement(query);
            pst.setString(1, catCode);
            rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
    
    public static boolean validateSupCode(String supCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DataBase.getConnection();

            String query = "SELECT s_code FROM supplier WHERE s_code = ?;";
            pst = conn.prepareStatement(query);
            pst.setString(1, supCode);
            rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
    
    public static boolean validateCusCode(String cusCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DataBase.getConnection();

            String query = "SELECT cus_code FROM customer WHERE cus_code = ?;";
            pst = conn.prepareStatement(query);
            pst.setString(1, cusCode);
            rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
    
    public static boolean validateTransaction(int t_id) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DataBase.getConnection();

            String query = "SELECT transaction_id FROM 'transaction' WHERE transaction_id = ?;";
            pst = conn.prepareStatement(query);
            pst.setInt(1, t_id);
            rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
}
