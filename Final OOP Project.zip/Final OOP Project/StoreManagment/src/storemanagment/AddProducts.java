/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */

public interface AddProducts {
    public int addProduct (String name, float price, int quantity, String supplier, String category);
    public void updateStock(String code, String name, int quantity, float price);
}
