/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
public class InventoryManagment {

    // Private Attributes
    private String category_code;
    private String product_code;
    private String product_name;
    private String supplier_id;
    private float price;
    private int quantity;

    // Constructor
    public InventoryManagment(String category_code, String product_code, String product_name,
            float price, int quantity, String supplier_id) {
        this.category_code = category_code;
        this.product_code = product_code;
        this.product_name = product_name;
        this.price = price;
        this.quantity = quantity;
        this.supplier_id = supplier_id;
    }

    public InventoryManagment(String product_code, int quantity) {

        this.product_code = product_code;
        this.quantity = quantity;
    }

    // Getter and Setter for category_code
    public String getCategoryCode() {
        return category_code;
    }

    public String getsupplierId() {
        return supplier_id;
    }

    public void setCategoryCode(String category_code) {
        this.category_code = category_code;
    }

    public void setsupplierId(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    // Getter and Setter for product_code
    public String getProductCode() {
        return product_code;
    }

    public void setProductCode(String product_code) {
        this.product_code = product_code;
    }

    // Getter and Setter for product_name
    public String getProductName() {
        return product_name;
    }

    public void setProductName(String product_name) {
        this.product_name = product_name;
    }

    // Getter and Setter for price
    public double getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    // Getter and Setter for quantity
    public int getQuantity() {
        return quantity;
    }
}
