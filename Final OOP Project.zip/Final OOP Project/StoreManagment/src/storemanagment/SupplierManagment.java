/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storemanagment;

/**
 *
 * @author AFAN
 */
public class SupplierManagment {

    // Attributes
    private String supplier_id;
    private String supplier_name;
    private String supplier_address;
    private float total_sales;
    // Constructor
    public SupplierManagment(String supplier_id, String supplier_name, String supplier_address,float total_sales) {
        this.supplier_id = supplier_id;
        this.supplier_name = supplier_name;
        this.supplier_address = supplier_address;
        this.total_sales=total_sales;
    }

    // Getters
    public String getSupplierId() {
        return supplier_id;
    }
    public Float getSupplierSales() {
        return total_sales;
    }

    public String getSupplierName() {
        return supplier_name;
    }

    public String getSupplierAddress() {
        return supplier_address;
    }

    // Setters
    public void setSupplierId(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    public void setSupplierName(String supplier_name) {
        this.supplier_name = supplier_name;
    }
    public void setSupplierSales(Float total_sales) {
        this.total_sales=total_sales;
    }

    public void setSupplierAddress(String supplier_address) {
        this.supplier_address = supplier_address;
    }

}
